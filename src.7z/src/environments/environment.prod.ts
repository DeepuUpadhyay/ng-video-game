export const environment = {
  production: true,
  BASE_URL: 'https://rawg-video-games-database.p.rapidapi.com',
};
